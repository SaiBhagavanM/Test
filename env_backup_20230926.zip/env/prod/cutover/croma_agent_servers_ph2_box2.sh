 main_date_str=`date +%h_%d`


echo "AdjustInv_Int "
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh AdjustInv_Int > /apps/IBM/sterling10/foundation/logs/AdjustInv_Int_${main_date_str}.log &
sleep 10;

echo "CreateOrder_INT "
nohup /apps/IBM/sterling10/foundation/scripts/agentServer_high.sh CreateOrder_INT > /apps/IBM/sterling10/foundation/logs/CreateOrder_INT_${main_date_str}.log &
sleep 10;


echo "ManualOrderServerAgt "
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh ManualOrderServerAgt > /apps/IBM/sterling10/foundation/logs/ManualOrderServerAgt_${main_date_str}.log &
sleep 10;

echo "ItemOutbound_Int "
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh ItemOutbound_Int > /apps/IBM/sterling10/foundation/logs/ItemOutbound_Int_${main_date_str}.log &
sleep 10;

echo "MCHUpload_Int "
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh MCHUpload_Int > /apps/IBM/sterling10/foundation/logs/MCHUpload_Int_${main_date_str}.log &
sleep 10;

echo "ManageTaxLoad_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh ManageTaxLoad_Int > /apps/IBM/sterling10/foundation/logs/ManageTaxLoad_Int_${main_date_str}.log &
sleep 10;

echo "ManualOrdersLoadAgt "
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh ManualOrdersLoadAgt > /apps/IBM/sterling10/foundation/logs/ManualOrdersLoadAgt_${main_date_str}.log &
sleep 10;

echo "PublishPricing_AGT "
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh PublishPricing_AGT > /apps/IBM/sterling10/foundation/logs/PublishPricing_AGT_${main_date_str}.log &
sleep 10;

echo "MPOrderReplace_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh MPOrderReplace_Int > /apps/IBM/sterling10/foundation/logs/MPOrderReplace_Int_${main_date_str}.log &
sleep 10;

echo "MPOrderReturn_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh MPOrderReturn_Int /apps/IBM/sterling10/foundation/logs/MPOrderReturn_Int_${main_date_str}.log &
sleep 10;

echo "ChangeOrderStatusInt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh ChangeOrderStatusInt /apps/IBM/sterling10/foundation/logs/ChangeOrderStatusInt_${main_date_str}.log &
sleep 10;

echo "UpdateCIMCSDStatus_INT "
nohup /apps/IBM/sterling10/foundation/scripts/agentServer_high.sh UpdateCIMCSDStatus_INT > /apps/IBM/sterling10/foundation/logs/UpdateCIMCSDStatus_INT_${main_date_str}.log &
sleep 10;

echo "MPOrderCancel_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh MPOrderCancel_Int > /apps/IBM/sterling10/foundation/logs/MPOrderCancel_Int_${main_date_str}.log &
sleep 10;

echo "**************** new ph2 agents *************"

echo "Ph2CreateOrderInt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer_high.sh Ph2CreateOrderInt > /apps/IBM/sterling10/foundation/logs/Ph2CreateOrderInt_${main_date_str}.log &
sleep 10 ;

echo "Ph2_InvoicePrint_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh Ph2_InvoicePrint_Int > /apps/IBM/sterling10/foundation/logs/Ph2_InvoicePrint_Int_${main_date_str}.log &
sleep 10 ;

echo "Ph2_PublishInvoiceDetails_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh Ph2_PublishInvoiceDetails_Int > /apps/IBM/sterling10/foundation/logs/Ph2_PublishInvoiceDetails_Int_${main_date_str}.log &
sleep 10 ;

echo "Ph2_Croma_CreateShipInv_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh Ph2_Croma_CreateShipInv_Int > /apps/IBM/sterling10/foundation/logs/Ph2_Croma_CreateShipInv_Int_${main_date_str}.log &
sleep 10 ;
