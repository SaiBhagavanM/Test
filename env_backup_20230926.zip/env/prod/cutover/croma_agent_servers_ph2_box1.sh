#/bin/bash
#main_${main_date_str}_str=`${main_date_str} +%Y%m%d%H%M%S`

main_date_str=`date +%h_%d`

echo " FullInventoryLoad_Int1 "
nohup /apps/IBM/sterling10/foundation/scripts/agentServer_high.sh FullInventoryLoad_Int1 > /apps/IBM/sterling10/foundation/logs/FullInventoryLoad_Int1_${main_date_str}.log &
sleep 10;

echo "CromaReservationPurgeAgt "
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaReservationPurgeAgt > /apps/IBM/sterling10/foundation/logs/CromaReservationPurgeAgt_${main_date_str}.log &
sleep 10;

echo "CreateOrder_INT"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer_high.sh CreateOrder_INT > /apps/IBM/sterling10/foundation/logs/CreateOrder_INT_${main_date_str}.log &
sleep 10;

echo "ManageItem_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh ManageItem_Int > /apps/IBM/sterling10/foundation/logs/ManageItem_Int_${main_date_str}.log &
sleep 10;

echo "InvoicePrint_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh InvoicePrint_Int > /apps/IBM/sterling10/foundation/logs/InvoicePrint_Int_${main_date_str}.log &
sleep 10;

echo "PublishInvoiceDetails_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh PublishInvoiceDetails_Int > /apps/IBM/sterling10/foundation/logs/PublishInvoiceDetails_Int_${main_date_str}.log &
sleep 10;

echo "CreateTaxLoad_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CreateTaxLoad_Int > /apps/IBM/sterling10/foundation/logs/PublishInvoiceDetails_Int_${main_date_str}.log &
sleep 10;

echo "ManageOrganization_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh ManageOrganization_Int > /apps/IBM/sterling10/foundation/logs/ManageOrganization_Int_${main_date_str}.log &
sleep 10;

echo "CreateUser_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CreateUser_Int > /apps/IBM/sterling10/foundation/logs/CreateUser_Int_${main_date_str}.log &
sleep 10;

echo "ManageCustomer_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh ManageCustomer_Int > /apps/IBM/sterling10/foundation/logs/ManageCustomer_Int_${main_date_str}.log &
sleep 10;

echo "DeleteTaxLoad_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh DeleteTaxLoad_Int > /apps/IBM/sterling10/foundation/logs/DeleteTaxLoad_Int_${main_date_str}.log &
sleep 10;

echo "**************** new ph2 agents *************"

echo "Ph2CreateOrderInt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer_high.sh Ph2CreateOrderInt > /apps/IBM/sterling10/foundation/logs/Ph2CreateOrderInt_${main_date_str}.log &
sleep 10 ;

echo "Ph2_Create_RTO_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh Ph2_Create_RTO_Int > /apps/IBM/sterling10/foundation/logs/Ph2_Create_RTO_Int_${main_date_str}.log &
sleep 10 ;

echo "Ph2_CromaOrderOutbound_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh Ph2_CromaOrderOutbound_Int > /apps/IBM/sterling10/foundation/logs/Ph2_CromaOrderOutbound_Int_${main_date_str}.log &
sleep 10 ;

echo "Ph2_CromaReturnOut_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh Ph2_CromaReturnOut_Int > /apps/IBM/sterling10/foundation/logs/Ph2_CromaReturnOut_Int_${main_date_str}.log &
sleep 10 ;

echo "PH2_OnReturnReceipt_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh PH2_OnReturnReceipt_Int > /apps/IBM/sterling10/foundation/logs/PH2_OnReturnReceipt_Int_${main_date_str}.log &
sleep 10 ;

echo "Ph2_UpdateAIHold_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh Ph2_UpdateAIHold_Int > /apps/IBM/sterling10/foundation/logs/Ph2_UpdateAIHold_Int_${main_date_str}.log &
sleep 10 ;

echo "Ph2CancelOrderInt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh Ph2CancelOrderInt > /apps/IBM/sterling10/foundation/logs/Ph2CancelOrderInt_${main_date_str}.log &
sleep 10 ;

echo "Ph2ChangeShipmentStatusInt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh Ph2ChangeShipmentStatusInt > /apps/IBM/sterling10/foundation/logs/Ph2ChangeShipmentStatusInt_${main_date_str}.log &
sleep 10 ;

echo "Ph2CromaReturnScheduleAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh Ph2CromaReturnScheduleAgt > /apps/IBM/sterling10/foundation/logs/Ph2CromaReturnScheduleAgt_${main_date_str}.log &
sleep 10 ;

echo "Ph2ConfirmShipmentInt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer_high.sh Ph2ConfirmShipmentInt > /apps/IBM/sterling10/foundation/logs/Ph2ConfirmShipmentInt_${main_date_str}.log &
sleep 10 ;
