main_date_str=`date +%h_%d`

echo "CromaPh2_Delhivery_OrderStatusUpdateAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh   CromaPh2_Delhivery_OrderStatusUpdateAgt > /apps/IBM/sterling10/foundation/logs/CromaPh2_Delhivery_OrderStatusUpdateAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_EcomExpress_OrderStatusUpdAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_EcomExpress_OrderStatusUpdAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_EcomExpress_OrderStatusUpdAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_IRNNoGenerationAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_IRNNoGenerationAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_IRNNoGenerationAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_IRNNoTrackAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_IRNNoTrackAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_IRNNoTrackAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_ValidateIMEISerialNoAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_ValidateIMEISerialNoAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_ValidateIMEISerialNoAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_XpressBees_OrderStatusUpdAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_XpressBees_OrderStatusUpdAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_XpressBees_OrderStatusUpdAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_Delhivery_PinCodePopulatorAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_Delhivery_PinCodePopulatorAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_Delhivery_PinCodePopulatorAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_EcomExpress_OrderStatusUpdateAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_EcomExpress_OrderStatusUpdateAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_EcomExpress_OrderStatusUpdateAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_EcomExpress_PinCodePopulatorAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_EcomExpress_PinCodePopulatorAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_EcomExpress_PinCodePopulatorAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_ExpressBees_OrderStatusUpdateAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_ExpressBees_OrderStatusUpdateAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_ExpressBees_OrderStatusUpdateAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_StatisticsPurgeAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_StatisticsPurgeAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_StatisticsPurgeAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_ExportPurgeAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_ExportPurgeAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_ExportPurgeAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_InboxPurgeAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_InboxPurgeAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_InboxPurgeAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_InventoryAuditPurgeAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_InventoryAuditPurgeAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_InventoryAuditPurgeAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_ReprocessErrorPurgeAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_ReprocessErrorPurgeAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_ReprocessErrorPurgeAgt_${main_date_str}.log &
sleep 10 ;

echo "Ph2_CreateShipment_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer_high.sh Ph2_CreateShipment_Int  > /apps/IBM/sterling10/foundation/logs/Ph2_CreateShipment_Int_${main_date_str}.log &
sleep 10 ;

echo "Ph2CreateShipment_HDEL_Int"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer_high.sh Ph2CreateShipment_HDEL_Int  > /apps/IBM/sterling10/foundation/logs/Ph2CreateShipment_HDEL_Int_${main_date_str}.log &
sleep 10 ;

echo "Ph2CromaReleaseOrdAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer_high.sh Ph2CromaReleaseOrdAgt  > /apps/IBM/sterling10/foundation/logs/Ph2CromaReleaseOrdAgt_${main_date_str}.log &
sleep 10 ;

echo "Ph2CromaScheduleOrdAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer_high.sh Ph2CromaScheduleOrdAgt  > /apps/IBM/sterling10/foundation/logs/Ph2CromaScheduleOrdAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_ScheduleBackOrderAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_ScheduleBackOrderAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_ScheduleBackOrderAgt_${main_date_str}.log &
sleep 10 ;

echo "CromaPh2_BnmAndEcomReportAgt"
nohup /apps/IBM/sterling10/foundation/scripts/agentServer.sh CromaPh2_BnmAndEcomReportAgt  > /apps/IBM/sterling10/foundation/logs/CromaPh2_BnmAndEcomReportAgt_${main_date_str}.log &
sleep 10 ;